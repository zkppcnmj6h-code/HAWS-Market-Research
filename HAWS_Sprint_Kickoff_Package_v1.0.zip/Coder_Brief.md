---
document_type: sprint_brief
workstream: HAWS_20_PRODUCT_DEVELOPMENT
owner: Coder
sprint: S1_Ingest_Score_Serve
status: Not_Started
created: 2025-10-09
reviewed_by: Software Architect
---

# Coder's Brief: Ingest → Score → Serve Sprint

**Owner:** Coder  
**Sprint:** S1 (Ingest → Score → Serve)  
**Date:** 2025-10-09  
**Status:** Not Started

---

## 1. Objective

Your primary objective is to implement the functional core of the "Ingest → Score → Serve" pipeline as defined by the Architect. You are responsible for writing clean, tested, and efficient code that aligns fully with the architectural specifications and coding standards established for this sprint.

You will translate the Architect’s design into operational systems — ingesting data, validating it, applying risk scoring logic, and exposing it through an accessible API.

## 2. Key Deliverables

You are **Responsible (R)** for producing the following artifacts:

1. **Validation Script (`validate_stream.py`):**  
   Implements schema-based validation for incoming event streams according to the `ingest_schema.json` provided by the Architect. Invalid entries should be logged with precise error messages.

2. **Risk Scoring Script (`risk_score.py`):**  
   Implements the deterministic rules defined in `risk_rules.yaml` to generate a `risk_score`, `risk_label`, and `explanations[]` for each event. Ensure modular design for future ML model integration.

3. **API Implementation (`app.py`):**  
   Implements the FastAPI/Flask application exposing the v1 endpoints specified in the Architect’s OpenAPI document. The application must conform exactly to the versioned API contract.

4. **Unit & Integration Tests:**  
   Complete testing coverage for validation, scoring, and API layers. Include sample golden datasets for CI testing.

5. **Minimal React UI:**  
   Implements a simple front-end (React or Vite) that consumes live API data, displaying risk summaries, top entities, and individual entity details.

*All deliverables must follow HAWS versioning conventions: `[YYYY-MM-DD]_Title_vX`.*

## 3. Success Criteria

This brief is considered complete when:

- All code passes linting, type checks, and tests defined in CI.  
- The system processes pilot-sized datasets end-to-end without error.  
- API endpoints match the versioned OpenAPI spec exactly, with zero contract drift.  
- The UI correctly fetches and displays data from the live API.  
- The Architect has reviewed and approved all pull requests related to your work.  

## 4. Dependencies & Collaborators

- **You are dependent on:**
  - The Architect’s finalized `ingest_schema.json`, `risk_rules.yaml`, and OpenAPI specification.
  - The Project Lead for clarification on business logic or data semantics.

- **The following roles are dependent on you:**
  - **The Architect:** Requires your implementation to validate design assumptions and complete API integration testing.
  - **The Strategic Coordinator:** Requires your code and documentation to be properly filed for repository maintenance and sprint tracking.

## 5. Review Cadence & Process

As defined in the Leadership Principles, reviews occur at key milestones — not daily.

- **Initial Code Review:** Submit your first working implementation of the validation and scoring scripts by **Day 5** for Architect review.
- **API Integration Review:** Complete API functionality and tests by **Day 9**, subject to joint review by Architect and Project Lead.
- **UI Demonstration:** Present a functional front-end connected to the live API by **Day 12**.
- **Final Review:** All deliverables to be verified by the Architect and logged by the Coordinator by the end of **Day 14**.

## 6. Repository & Filing

All code and documentation must be stored in the following designated HAWS directories:

- **Validation Script:** `/HAWS_20_PRODUCT_DEVELOPMENT/02_Backend_Scripts/Data_Pipelines/`
- **Risk Scoring Script:** `/HAWS_20_PRODUCT_DEVELOPMENT/03_Analytics/Predictive_Models/`
- **API Implementation:** `/HAWS_20_PRODUCT_DEVELOPMENT/02_Backend_Scripts/API_Integrations/`
- **Tests:** `/HAWS_20_PRODUCT_DEVELOPMENT/02_Backend_Scripts/Tests/`
- **UI Files:** `/HAWS_20_PRODUCT_DEVELOPMENT/01_MVP_Prototypes/Safety_Twin/ui/`

The **Strategic Coordinator** is responsible for validating that each artifact has been correctly filed and linked in the `Change_Log.xlsx`.

---
